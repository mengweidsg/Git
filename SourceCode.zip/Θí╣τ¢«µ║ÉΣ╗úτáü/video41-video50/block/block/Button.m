//
//  Button.m
//  block
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "Button.h"

@implementation Button
- (void)click {
    _block(self);
}
@end
