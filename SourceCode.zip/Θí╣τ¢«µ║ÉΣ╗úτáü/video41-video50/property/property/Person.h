//
//  Person.h
//  property
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject {
    int _ID;
    float _weight;
}

@property int ID;

@property float weight;
@end
