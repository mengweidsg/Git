//
//  Teacher.h
//  property
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Teacher : NSObject

@property int age;
@end
