//
//  Person.m
//  property
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "Person.h"

@implementation Person

@synthesize ID = _ID;
@synthesize weight = _weight;

//- (void)setWeight:(float)weight {
//    _weight = weight * 1000;
//}

//- (float)weight {
//    return _weight * 1000;
//}
@end
