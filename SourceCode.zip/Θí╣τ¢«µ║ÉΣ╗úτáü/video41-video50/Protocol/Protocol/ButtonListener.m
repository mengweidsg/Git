//
//  ButtonListener.m
//  Protocol
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "ButtonListener.h"
#import "Button.h"

@implementation ButtonListener
- (void)onClick {
    NSLog(@"ButtonListener已经监听到按钮被点击了");
}
@end
