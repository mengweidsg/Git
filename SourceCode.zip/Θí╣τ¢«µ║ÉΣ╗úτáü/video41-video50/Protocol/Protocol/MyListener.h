//
//  MyListener.h
//  Protocol
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ButtonDelegate;

@interface MyListener : NSObject <ButtonDelegate>

@end
