//
//  B.h
//  @class关键字
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@class A;

@interface B : NSObject

@property A *a;
@end
