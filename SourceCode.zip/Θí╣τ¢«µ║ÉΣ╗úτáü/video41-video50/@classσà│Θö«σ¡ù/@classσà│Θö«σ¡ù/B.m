//
//  B.m
//  @class关键字
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "B.h"

@implementation B

@end
