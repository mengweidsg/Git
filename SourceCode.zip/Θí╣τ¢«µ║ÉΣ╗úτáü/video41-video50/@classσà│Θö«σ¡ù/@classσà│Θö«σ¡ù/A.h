//
//  A.h
//  @class关键字
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>
@class B;

@interface A : NSObject
@property B *b;
@end
