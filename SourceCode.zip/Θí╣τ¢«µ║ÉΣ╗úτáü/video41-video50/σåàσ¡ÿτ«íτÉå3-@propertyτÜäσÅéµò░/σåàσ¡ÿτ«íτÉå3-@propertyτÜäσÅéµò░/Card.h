//
//  Card.h
//  内存管理3-@property的参数
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Card : NSObject

@end
