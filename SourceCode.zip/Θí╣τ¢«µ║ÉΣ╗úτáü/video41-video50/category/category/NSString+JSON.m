//
//  NSString+JSON.m
//  category
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "NSString+JSON.h"

@implementation NSString (JSON)
+ (NSString *)json {
return @"{'id':10, 'name':'mj'}";
}
@end
