//
//  Student+Test.m
//  category
//
//  Created by mj on 13-4-4.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "Student+Test.h"

@implementation Student (Test)

- (void)test2 {
    NSLog(@"调用了test2方法");
}

@end
