//
//  GoodStudent.h
//  成员变量补充
//
//  Created by mj on 13-4-5.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "Student.h"

@interface GoodStudent : Student

@end
