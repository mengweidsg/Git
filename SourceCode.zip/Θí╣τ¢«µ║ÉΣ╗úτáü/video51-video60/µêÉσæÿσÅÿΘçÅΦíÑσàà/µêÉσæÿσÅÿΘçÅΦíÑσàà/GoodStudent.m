//
//  GoodStudent.m
//  成员变量补充
//
//  Created by mj on 13-4-5.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "GoodStudent.h"

@implementation GoodStudent
- (void)test {
    age = 10;
    
    no = 9;
    
    height = 5.6f;
}
@end
