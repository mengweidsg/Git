//
//  Student.h
//  Foundation6-NSArray
//
//  Created by mj on 13-4-5.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

+ (id)student;

- (void)test;

- (void)test2:(NSString *)str;
@end
