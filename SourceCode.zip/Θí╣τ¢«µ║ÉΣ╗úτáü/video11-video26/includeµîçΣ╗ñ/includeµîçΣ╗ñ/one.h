//
//  one.h
//  include指令
//
//  Created by mj on 13-3-26.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#ifndef _ONE_H_

#define _ONE_H_

void one();

#endif
