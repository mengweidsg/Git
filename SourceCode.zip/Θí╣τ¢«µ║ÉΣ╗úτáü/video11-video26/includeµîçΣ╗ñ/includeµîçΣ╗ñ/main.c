//
//  main.c
//  include指令
//
//  Created by mj on 13-3-26.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#include <stdio.h>

#include "one.h"
#include "two.h"

int main(int argc, const char * argv[])
{
    
    one();
    
    two();
    return 0;
}

