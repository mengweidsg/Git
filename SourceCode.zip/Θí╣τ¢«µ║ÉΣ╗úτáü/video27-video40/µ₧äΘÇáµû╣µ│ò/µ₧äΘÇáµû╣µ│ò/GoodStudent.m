//
//  GoodStudent.m
//  构造方法
//
//  Created by mj on 13-3-28.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "GoodStudent.h"

@implementation GoodStudent

// 子类访问了父类的成员变量
- (void)test {
    _age = 10;
}
@end
