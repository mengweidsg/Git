//
//  GoodStudent.h
//  构造方法
//
//  Created by mj on 13-3-28.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "Student.h"

@interface GoodStudent : Student

@end
