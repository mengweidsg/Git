//
//  one.h
//  extern与函数
//
//  Created by mj on 13-3-28.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#ifndef extern____one_h
#define extern____one_h

// 完整地声明一个函数，需要用到extern关键字，表示引用一个外部函数
// extern void one();

// 其实extern又是废的，所以可以省略
void one();

#endif
