//
//  main.c
//  extern与函数
//
//  Created by mj on 13-3-28.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#include <stdio.h>

#include "one.h"

int main(int argc, const char * argv[])
{
    one();
    return 0;
}

