//
//  main.c
//  基本数据类型-变量的使用
//
//  Created by mj on 13-3-25.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#include <stdio.h>


int main(int argc, const char * argv[])
{
    
    char a = 'A';
    
    char b = 65;
    
    printf("%d", 'c' - 'A');
    
    // 错误写法
//    char c1 = '我';
//    char c2 = '123';
//    char c3 = "123";
    
    return 0;
}

