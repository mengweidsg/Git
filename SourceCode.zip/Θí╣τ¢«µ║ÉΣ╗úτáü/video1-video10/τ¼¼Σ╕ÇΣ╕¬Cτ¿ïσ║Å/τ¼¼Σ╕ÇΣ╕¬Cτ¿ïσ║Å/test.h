//
//  test.h
//  第一个C程序
//
//  Created by mj on 13-3-25.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

// 将test函数放到main函数前面做一个提前"声明"
void test();
// 声明sum函数
int sum(int, int);
