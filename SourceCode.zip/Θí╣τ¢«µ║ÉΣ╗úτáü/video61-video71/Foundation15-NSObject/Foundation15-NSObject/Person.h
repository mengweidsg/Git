//
//  Person.h
//  Foundation15-NSObject
//
//  Created by mj on 13-4-7.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
- (void)test;
@end
