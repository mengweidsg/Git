//
//  Person.m
//  Foundation15-NSObject
//
//  Created by mj on 13-4-7.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "Person.h"

@implementation Person
- (void)test {
    NSLog(@"调用了Person的test方法");
}
@end
