//
//  Student.m
//  Foundation15-NSObject
//
//  Created by mj on 13-4-7.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "Student.h"

@implementation Student


- (void)test {
    NSLog(@"调用了test方法");
}

- (void)test2:(NSString *)a {
    NSLog(@"调用了test2方法:%@", a);
}

@end
